# Muhammadi Public Secondary School — Android App

School Code: 350102003

This is a lightweight Android WebView wrapper around the existing Google Apps Script Web App. It does not modify the Apps Script or Google Sheet; the same web application remains the backend/UI.

## Free APK build
The repository includes a GitHub Actions workflow. Upload this project to a GitHub repository and run **Actions → Build Android APK**. The workflow produces a debug APK as an artifact; no paid Android service is required.

## Important
The app requires internet access because the current backend is a Google Apps Script URL. Existing web functions remain in the Apps Script page. Camera, microphone, location and file-picker capabilities are requested so common web-app functions continue to work.
